"""Print process module for separate process print dialog."""

from .main import main

__all__ = ['main']
